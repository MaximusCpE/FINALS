let quote = document.getElementById('quote');
let author = document.getElementById('author');
let btn = document.getElementById('btn');
const url = 'https://api.quotable.io/random';

// Function to update the displayed quote and author
const updateQuote = (content, authorName) => {
  quote.innerText = content;
  author.innerText = authorName;
};


// Function to fetch a random quote from the API
const getQuote = () => {
  fetch(url)
    .then((data) => data.json())
    .then((item) => {
      updateQuote(`"${item.content}"`, item.author);
    });
};

// Function to copy text to clipboard
const copyToClipboard = (text) => {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
};

btn.addEventListener('click', getQuote);

quote.addEventListener('click', () => {
  copyToClipboard(quote.innerText);
});